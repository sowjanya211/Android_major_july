package com.example;

import android.app.Activity;

public class MainActivity extends Activity {
}
